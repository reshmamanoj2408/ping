ALTER TABLE `channel_group`
  MODIFY COLUMN `saasGroupName` varchar(4000);
